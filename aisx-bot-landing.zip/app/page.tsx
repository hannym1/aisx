import AISXBotLanding from "../aisx-bot-landing"

export default function Page() {
  return <AISXBotLanding />
}
